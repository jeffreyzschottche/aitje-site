# AITJE Coder — aura

Zelfstandig websitevoorbeeld, speciaal voor de productpagina geschreven. Geen benchmark van een lokaal model.

Start een lokale webserver in deze map:

    python3 -m http.server 8080

Open http://localhost:8080. De voorbeelddata blijven in het geheugen.

De render is al gebundeld en werkt zonder installatie. Wil je de broncode veranderen? Pas aura.js aan, voer npm install uit en daarna npm run build. Three.js en esbuild behouden hun eigen licentie.
