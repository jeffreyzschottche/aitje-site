# AITJE Coder — board

Zelfstandig websitevoorbeeld, speciaal voor de productpagina geschreven. Geen benchmark van een lokaal model.

Start een lokale webserver in deze map:

    python3 -m http.server 8080

Open http://localhost:8080. De voorbeelddata blijven in het geheugen.
